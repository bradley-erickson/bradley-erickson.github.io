from dash import html

layout = html.H1('Page 1')
page = {
    'path': '/page1',
    'layout': layout,
    'name': 'Page 1'
}
